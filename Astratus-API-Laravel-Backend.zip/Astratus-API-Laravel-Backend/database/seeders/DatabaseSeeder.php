<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {

        //all the seeders
        $this->call(UsersSeeder::class);
        $this->call(CategoriesSeeder::class);
        $this->call(ServicesSeeder::class);
        $this->call(HistorySeeder::class);

    }//run

}//class
