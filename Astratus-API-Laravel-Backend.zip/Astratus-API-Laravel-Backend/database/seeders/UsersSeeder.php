<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use DB;

class UsersSeeder extends Seeder
{
    public function run(): void
    {
       
        DB::table('USERS')->insert([
            'USER'=>'chris@gmail.com',
            'PASSWORD'=>Hash::make('12345'),
            'CODE'=>'qwerty',
            'DATEEXPIRES'=>'2023-01-01',
            'STATUS'=>1
        ]);

        DB::table('USERS')->insert([
            'USER'=>'cron@astratus.com',
            'PASSWORD'=>Hash::make('5tuZ.m10'),
            'CODE'=>'qwerty',
            'DATEEXPIRES'=>'2023-01-01',
            'STATUS'=>1
        ]);

    }//run

}//class
