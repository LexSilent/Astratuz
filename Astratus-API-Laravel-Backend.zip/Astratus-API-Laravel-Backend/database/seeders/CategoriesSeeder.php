<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use DB;

class CategoriesSeeder extends Seeder
{
    public function run(): void
    {
       DB::table('CATEGORIES')->insert([
        'CATEGORY'=>'FARMACIES'
       ]);

       DB::table('CATEGORIES')->insert([
        'CATEGORY'=>'HOSPITALS'
       ]);
    }//run
}//class
