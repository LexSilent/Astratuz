<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use DB;

class ServicesSeeder extends Seeder
{
    // STATUS
    // 1 SERVICE OUTAGE
    // 2 DISTURB
    // 3 AVIALABLE
    public function run(): void
    {
        DB::table('SERVICES')->insert([
            'SERVICE'=>'WEB SERVICE CHRIS',
            'DESCRIPTION'=>'IS A STORE FROM FARMACIAS GUADALAJARA',
            'CATEGORY'=>1,
            'STATUS'=>3,
            'URL'=>'192.168.100.38'
        ]);

        DB::table('SERVICES')->insert([
            'SERVICE'=>'WEB SERVICE ANGIE',
            'DESCRIPTION'=>'IS A STORE FROM FARMACIAS GUADALAJARA2',
            'CATEGORY'=>1,
            'STATUS'=>2,
            'URL'=>'192.168.100.66'
        ]);

        DB::table('SERVICES')->insert([
            'SERVICE'=>'WEB SERVICE JOEL',
            'DESCRIPTION'=>'IS A STORE FROM FARMACIAS GUADALAJARA3',
            'CATEGORY'=>1,
            'STATUS'=>2,
            'URL'=>'192.168.100.42'
        ]);
    }//run
}//class
