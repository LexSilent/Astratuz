<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use DB;

class HistorySeeder extends Seeder
{
    public function run(): void
    {
        
        DB::table('HISTORY')->insert([
            'SERVICE'=>1,
            'STATUS'=>1,
            'CAUSE'=>'SODA IN THE SERVER',
            'SOLUTION'=>'MORE SODA, STILL NOT DIE CHAT GPT',
            'DATESTARTED'=>'2023-04-11 03:04:22',
            'DATEFIXED'=> null
        ]);

        DB::table('HISTORY')->insert([
            'SERVICE'=>2,
            'STATUS'=>2,
            'CAUSE'=>'THE ENGINER THIEF THE SERVER',
            'SOLUTION'=>'NONE',
            'DATESTARTED'=>'2023-5-11 17:00:00',
            'DATEFIXED'=>'2023-5-13 18:44:20'
        ]);

    }//run

}//class
