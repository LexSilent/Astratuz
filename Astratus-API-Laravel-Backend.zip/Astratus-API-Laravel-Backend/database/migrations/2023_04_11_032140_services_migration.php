<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

return new class extends Migration
{

    public function up(): void
    {
        Schema::create('SERVICES',function(Blueprint $table){
            $table->increments('ID');
            $table->string('SERVICE');
            $table->string('DESCRIPTION');

            $table->integer('CATEGORY')->unsigned();
            $table->foreign('CATEGORY')->references('ID')->on('CATEGORIES');

            $table->integer('STATUS');
            $table->string('URL');

            $table->timestamps();
        });
    }//up

    public function down(): void
    {
        Schema::dropIfExists('SERVICES');
    }//down
};
