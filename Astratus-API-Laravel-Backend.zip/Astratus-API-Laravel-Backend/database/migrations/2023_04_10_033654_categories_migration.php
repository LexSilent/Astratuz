<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

return new class extends Migration
{

    public function up(): void
    {
        Schema::create('CATEGORIES', function(Blueprint $table){
            $table->increments("ID");
            $table->string("CATEGORY");
            $table->timestamps();
        });
    }//up

    public function down(): void
    {
        Schema::dropIfExists('CATEGORIES');
    }//down
};
