<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

return new class extends Migration
{

    public function up(): void
    {
        Schema::create('HISTORY', function(Blueprint $table){
            $table->increments("ID");

            $table->integer('SERVICE')->unsigned();
            $table->foreign('SERVICE')->references('ID')->on('SERVICES');

            $table->integer('STATUS');
            $table->string('CAUSE')->nullable();
            $table->string('SOLUTION')->nullable();
            $table->dateTime('DATESTARTED');
            $table->dateTime('DATEFIXED')->nullable();

            $table->timestamps();

        });
    }//up

    public function down(): void
    {
        Schema::dropIfExists('HISTORY');
    }//down
};
