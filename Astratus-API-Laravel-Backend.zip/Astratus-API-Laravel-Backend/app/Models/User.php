<?php

namespace App\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    protected $table = "USERS";
    protected $fillable = [
        'USER',
        'PASSWORD',
        'CODE',
        'DATEEXPIRES',
        'STATUS'
    ];
}//class
