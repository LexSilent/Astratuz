<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Service extends Model
{
    protected $table = "SERVICES";

    protected $fillable = [
        'SERVICE',
        'CATEGORY',
        'DESCRIPTION',
        'STATUS',
        'LINK'
    ];
}//class
