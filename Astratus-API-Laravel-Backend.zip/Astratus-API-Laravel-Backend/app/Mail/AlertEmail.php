<?php

namespace App\Mail;

use Illuminate\Mail\Mailable;

class AlertEmail extends Mailable
{
    
    public $dataToSend;
    public function __construct($dataRecieved){
        $this->dataToSend = $dataRecieved;
    }//construct
    public function build(){
        return $this->view('alertView');
    }//build

}//class Mailable
