<?php

namespace App\Http\Controllers;

use App\Models\User;
use Hash;
use Symfony\Component\HttpFoundation\Request;
use Validator;

class UsersController extends Controller
{
    
    public function authenticate(Request $request){

        $rules = Validator::make($request->all(),[
            'USER'=>'required',
            'PASSWORD'=>'required'
        ]);

        if($rules->fails()){
            return response()->json([
                "DATA"=>"RULES FAILS"
            ]);
        }//if the rules fails
        else{

            $users = User::all();
            $response = $users->map( function ($i) use ($request){
                if($i["USER"] == $request->USER && Hash::check($request->PASSWORD,$i["PASSWORD"]))
                    return true;
            });
            if($response[0] != true) $response[0] = false;
            
            return response()->json([
                'DATA'=>$response[0]
            ]);

        }//else

    }//index

}//class
