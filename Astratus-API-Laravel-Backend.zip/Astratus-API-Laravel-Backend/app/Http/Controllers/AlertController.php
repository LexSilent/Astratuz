<?php

namespace App\Http\Controllers;
use App\Mail\AlertEmail;
use Symfony\Component\HttpFoundation\Request;
use Mail;
use Validator;

class AlertController extends Controller
{
    public function sendAlert(Request $request){
        $rules = Validator::make($request->all(),[
            'CONTACTS'=>'required',
            'SERVICE'=>'required',
            'STATUS'=>'required',
            'DATE'=>'required'
        ]);

        if($rules->fails()){
            return response()->json([
                "DATA"=>"RULES FAILS"
            ]);
        }//if rules fails
        else{
            Mail::to($request->CONTACTS)->send(new AlertEmail([$request->SERVICE,$request->STATUS,$request->DATE]));
            return response()->json([
                "DATA"=>"SENT"
            ]);
        }//else works
    }//sendAlert
}//class
