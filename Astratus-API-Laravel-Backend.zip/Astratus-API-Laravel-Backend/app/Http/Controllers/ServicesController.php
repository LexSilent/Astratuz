<?php

namespace App\Http\Controllers;
use App\Models\Service;
use App\Models\User;
use Hash;
use Mockery\CountValidator\Exception;
use Symfony\Component\HttpFoundation\Request;
use Validator;

class ServicesController extends Controller
{
    public function getStatus(Request $request){

        $rules = Validator::make($request->all(),[
            'USER'=>'required',
            'PASSWORD'=>'required'
        ]);

        if($rules->fails()){
            return response()->json([
                "DATA"=>"LOGIN IS EMPTY"
            ]);
        }//if the rules fails
        else{
            $users = User::all();
            $response = $users->map(function ($i) use ($request){
                if($i["USER"] == $request->USER && Hash::check($request->PASSWORD,$i["PASSWORD"]))
                    return true;
            });
            if($response[0] != true) $response[0] = false;

            if($response){
                $status = Service::all();
                return response()->json([
                    "DATA"=>$status
                ]);
            }
            else{
                return response()->json([
                    "DATA"=>"LOGIN FAILS"
                ]);
            }//fail to login
        }//else works

    }//getStatus

    public function updateStatus(Request $request){
    
        $rules = Validator::make($request->all(),[
            'SERVICEID',
            'STATUS',
            'USER',
            'PASSWORD'
        ]);

        if($rules->fails()){
            return response()->json(['DATA'=>'RULES OR LOGIN FAILS']);
        }//if rules fails
        else{
            $users = User::all();
            $response = $users->map(function ($i) use ($request){
                if($i['USER'] == $request->USER && Hash::check($request->PASSWORD,$i['PASSWORD']))
                    return true;
            });

            if($response[0] != true) $response[0] = false;

            if($response){
                try{

                    $id = $request->SERVICEID;
                    if(Service::where("ID",$id)->exists()){
                        $updated = Service::where("ID",$id)->update(['STATUS'=>$request->STATUS]);
                        return response()->json([
                            'DATA'=> 'SUCESS',
                            'UPDATED'=> $updated
                        ]);
                    }//if exists
                    else{
                        return response()->json([
                            'DATA'=>'SERVICE DOESNOT FOUND'
                        ]);
                    }//else doesnot exist
    
                }//try
                catch(Exception $e){
                    echo $e;
                }
            }
            else{
                return response()->json(['DATA'=>'LOGIN WRONG']);
            }//else login is bad
        }//else works
    }//updateStatus

}//class    
