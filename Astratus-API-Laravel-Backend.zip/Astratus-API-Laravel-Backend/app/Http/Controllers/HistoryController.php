<?php

namespace App\Http\Controllers;
use App\Models\History;
use App\Models\Service;
use Symfony\Component\HttpFoundation\Request;
use Validator;

class HistoryController extends Controller
{
    
    public function getHistory(Request $request){
        $rules = Validator::make($request->all(),
        [
            'STARTDATE'=>'required|date',
            'ENDDATE'=>'required|date|after:STARTDATE',
            'SERVICEID'=>'required' //is the ID
        ]
        );

        if(!Service::find($request->SERVICEID)){
            return response()->json([
                'DATA'=>'THE SERVICE DOESNOT EXIST'
            ]);
        }//if the service doesnot exist
        if($rules->fails()){
            return response()->json([
                'DATA'=>'THE RULES FAILS'
            ]);
        }//if the rules fails
        else{

            $data = History::where('ID','=',$request->SERVICEID)
                    ->where('DATESTARTED','>=',$request->STARTDATE)
                    ->where('DATESTARTED','<=', $request->ENDDATE)
                    ->get();

            if(sizeof($data) > 0){
                return response()->json([
                    'DATA'=>$data
                ]);
            }//if exist the history
            else{
                return response()->json([
                    'DATA'=>'NOT FOUND'
                ]);
            }
            
        }//else works
    }//class

    public function addHistory(Request $request){
        $rules = Validator::make($request->all(),
        [
            'DATE'=>'required|date',
            'SERVICEID'=>'required',
            'STATUS'=>'required'
        ]
        );

        if(!Service::find($request->SERVICEID)){
            return response()->json([
                'DATA'=>'THE SERVICE DOESNOT EXIST'
            ]);
        }//if the service doesnot exist
        if($rules->fails()){
            return response()->json([
                'DATA'=>'THE RULES FAILS'
            ]);
        }//if the rules fails
        else{

            $history = new History();
            $history->SERVICE = $request->SERVICEID;
            $history->STATUS = $request->STATUS;
            $history->DATA = $request->DATA;
            $history->save();

            return response()->json([
                'DATA'=>$history,
                'STATUS'=>'SUCCESS'
            ]);

        }//else works
    }//addHistory

}//class
