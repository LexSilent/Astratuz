<?php

use App\Http\Controllers\CategoriesController;
use App\Http\Controllers\HistoryController;
use App\Http\Controllers\ServicesController;
use App\Http\Controllers\UsersController;
use Illuminate\Support\Facades\Route;


//Route for get the authentication for the users
Route::post('users/authenticate',[UsersController::class,'authenticate']);

//Routes for get information from DB
Route::post('services/categories',[CategoriesController::class,'getCategories']);
Route::post('services/status',[ServicesController::class,'getStatus']);
Route::post('services/history',[HistoryController::class,'getHistory']);

//Route for send an email
Route::post('email/send',[EmailController::class,'sendEmail']);

//Route for update the database
Route::post('services/update/status',[ServicesController::class, 'updateStatus']);
Route::post('services/update/history',[HistoryController::class, 'addHistory']);

//for prevent the access to that routes, the frontend needs to login, and that data,
//is saved in react, and sends that data in all the routes