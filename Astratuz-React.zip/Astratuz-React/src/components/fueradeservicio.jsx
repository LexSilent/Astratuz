
import logo from '../assets/logo.jpg'

const Login = () => {
    
    
    return (
       <div>
        <ul>
            <li>Ejemplo de servicio web de astrazeneca</li>
            <li>Online</li>
        </ul>
       </div>
    )
}

export default Login