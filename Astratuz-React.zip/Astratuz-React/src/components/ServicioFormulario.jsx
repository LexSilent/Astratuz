import React, { useState } from 'react';

function ServicioFormulario(props) {

  const [input, setInput] = useState('');

  const manejarCambio = e => {
    setInput(e.target.value);
  }

  const manejarEnvio = e => {
    e.preventDefault();
    
    const tareaNueva = {
      status: 0,
      texto: input
    }

    props.onSubmit(tareaNueva);
  }


  return (
    <form 
      className='tarea-formulario'
      onSubmit={manejarEnvio}>
      <input 
        className='tarea-input'
        type='text'
        placeholder='Write a service'
        name='texto'
        onChange={manejarCambio}
      />
      <button className='tarea-boton'>
        Create service
      </button>
    </form>
  );
}

export default ServicioFormulario;
